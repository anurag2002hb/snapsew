
const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const serviceSchema = new Schema({
  shirt: {
    collar: {
      type: String
    },
    frontLook: {
      type: String
    },
    backLook: {
      type: String
    },
    placket: {
      type: String
    },
    cuff: {
      type: String
    },
    pocket: {
      type: String
    },
    addDate: {
      type: String
    },
    plan: {
      type: String
    },
    extraMessage: {
      type: String
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  pant: {
    collar: {
      type: String
    },
    frontLook: {
      type: String
    },
    backLook: {
      type: String
    },
    placket: {
      type: String
    },
    cuff: {
      type: String
    },
    pocket: {
      type: String
    },
    addDate: {
      type: String
    },
    plan: {
      type: String
    },
    extraMessage: {
      type: String
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    }
  }
  
});

module.exports = mongoose.model('Service', serviceSchema);
