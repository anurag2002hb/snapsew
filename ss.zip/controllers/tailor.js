const Product = require('../models/product');
const Service = require('../models/service');
const Order = require('../models/order');


exports.getServices = (req, res, next) => {
  // Product.find({ userId: req.user._id })
    // .select('title price -_id')
    // .populate('userId', 'name')
    // .then(products => {
    //   console.log(products);
    //   res.render('admin/products', {
    //     prods: products,
    //     pageTitle: 'Admin Products',
    //     path: '/admin/products'
    //   });
    // })
    // .catch(err => console.log(err));
    res.render('tailor/check', {
      pageTitle: 'All Products',
      path: '/products'
    })
};

exports.getCheckout = (req, res, next) => {
  res.render('tailor/checkout', {
        pageTitle: 'Checkout',
        path: '/products'
      })
};

exports.getCustomization = (req, res, next) => {
  res.render('tailor/shirt-form', {
    pageTitle: 'Customization',
    path: '/admin/add-product',
    editing: false
  });
};

exports.getPantCustomization = (req, res, next) => {
  res.render('tailor/pant-form', {
    pageTitle: 'Pant Customization',
    path: '/admin/add-product',
    editing: false
  });
};

exports.postCustomization = (req, res, next) => {
  const collar = req.body.collar;
  const frontLook = req.body.frontLook;
  const backLook = req.body.backLook;
  const placket = req.body.placket;
  const cuff = req.body.cuff;
  const pocket = req.body.pocket;
  const addDate = req.body.addDate;
  const plan = req.body.plan;
  const extraMessage = req.body.extraMessage;
  const service = new Service({
    shirt: {
      collar: collar,
      frontLook: frontLook,
      backLook: backLook,
      placket: placket,
      cuff: cuff,
      pocket: pocket,
      addDate: addDate,
      plan: plan,
      extraMessage: extraMessage,
      userId: req.user
    }
    
  });
  service
    .save()
    .then(result => {
      // console.log(result);
      console.log('Created Service');
      res.redirect('/');
    })
    .catch(err => {
      console.log(err);
    });
};


exports.postPantCustomization = (req, res, next) => {
  const collar = req.body.collar;
  const frontLook = req.body.frontLook;
  const backLook = req.body.backLook;
  const placket = req.body.placket;
  const cuff = req.body.cuff;
  const pocket = req.body.pocket;
  const addDate = req.body.addDate;
  const plan = req.body.plan;
  const extraMessage = req.body.extraMessage;
  const service = new Service({
    pant: {
      collar: collar,
      frontLook: frontLook,
      backLook: backLook,
      placket: placket,
      cuff: cuff,
      pocket: pocket,
      addDate: addDate,
      plan: plan,
      extraMessage: extraMessage,
      userId: req.user
    }
    
  });
  service
    .save()
    .then(result => {
      // console.log(result);
      console.log('Created Service');
      res.redirect('/checkout');
    })
    .catch(err => {
      console.log(err);
    });
};

// exports.postPantCustomization = (req, res, next) => {
//   const fullName = req.body.fullName;
//   const phoneNo = req.body.phoneNo;
//   const pincode = req.body.pincode;
//   const houseNo = req.body.houseNo;
//   const building = req.body.building;
//   const address = req.body.address;
//   const order = new Order({
//     address: {
//       fullName: fullName,
//       phoneNo: phoneNo,
//       pincode: pincode,
//       houseNo: houseNo,
//       building: building,
//       address: address
//     }
    
//   });
//   service
//     .save()
//     .then(result => {
//       // console.log(result);
//       console.log('Created Service');
//       res.redirect('/checkout');
//     })
//     .catch(err => {
//       console.log(err);
//     });
// };



exports.getTailor = (req, res, next) => {
  res.render('tailor/check', {
        pageTitle: 'All Products',
        path: '/products'
      })
};

exports.getTailorProducts = (req, res, next) => {
  res.render('tailor/tailor-products', {
        pageTitle: 'All Products',
        path: '/products'
      })
};

exports.getBlouseForm = (req, res, next) => {
  res.render('tailor/blouse-form', {
        pageTitle: 'Blouse Form',
        path: '/products'
      })
};

exports.getShirtForm = (req, res, next) => {
  res.render('tailor/shirt-form', {
        pageTitle: 'Shirt Form',
        path: '/products'
      })
};

exports.getPantForm = (req, res, next) => {
  res.render('tailor/pant-form', {
        pageTitle: 'Pant Form',
        path: '/products'
      })
};


exports.getCart = (req, res, next) => {
  res.render('tailor/cart', {
        pageTitle: 'Cart',
        path: '/products'
      })
};

exports.getCart = (req, res, next) => {
  req.user
    .populate('cart.items.productId')
    .execPopulate()
    .then(user => {
      const products = user.cart.items;
      res.render('shop/cart', {
        path: '/cart',
        pageTitle: 'Your Cart',
        products: products
      });
    })
    .catch(err => console.log(err));
};


exports.getServices = (req, res, next) => {
  console.log('its work');
  Service.find({ 'userId': req.user._id })
    .then(services => {
      res.render('tailor/cart', {
        path: '/orders',
        pageTitle: 'Your Orders',
        services: services
      });
    })
    .catch(err => console.log(err));
};

